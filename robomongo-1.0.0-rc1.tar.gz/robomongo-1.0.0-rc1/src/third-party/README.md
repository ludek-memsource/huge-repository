Third-party dependencies
========================
   
Robomongo automatically compiles and statically links to the following
libraries:

1. QJson 
2. QScintilla

You do not need to build them separately. 
