#pragma once

namespace Robomongo
{
    namespace HighDpiConstants
    {
        int const WIN_HIGH_DPI_BUTTON_HEIGHT = 23;
    }

} /* end of Robomongo namespace */
