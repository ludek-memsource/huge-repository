#define rbm_socket_t int
#define rbm_socket_invalid (-1)
