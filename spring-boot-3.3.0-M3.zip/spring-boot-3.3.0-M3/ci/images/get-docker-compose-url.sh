#!/bin/bash
set -e

version="2.17.0"
echo "https://github.com/docker/compose/releases/download/v$version/docker-compose-linux-x86_64"
